package ru.parhomych.weatherparhomych.retrofit;

public interface ApiKeys {
    public String ACCU_WEATHER_KEY = "RRlzOGafL3MOaFcrJ5HS0mf87ge22TN9";
}
