package ru.parhomych.weatherparhomych.retrofit;

import retrofit2.Retrofit;

public class RetrofitAccuWeather {

    private static Retrofit retrofitInstance;

    public static Retrofit getInstance() {
        if (retrofitInstance == null) {
            retrofitInstance = new Retrofit.Builder()
                    .baseUrl("http://dataservice.accuweather.com/")
                    .build();
        }
        return retrofitInstance;
    }

}
